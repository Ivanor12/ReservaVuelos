<?php
session_start();
if (isset($_SESSION['logueado'])) {
    include 'head.php';
    require_once 'clases/Conexion.php';
      try {
        $obj_conexion = new Conexion();
        $con = $obj_conexion->conectar();
        $sql ="select * from vuelos";
        $listado = $con->prepare($sql);
        $listado->execute();
        //Es un array asociativo con los registros de la consultas.
        $filas = $listado->fetchAll();
        //echo '<pre>';
        //var_dump($filas);
        //echo '</pre>';
        echo '
        <table>
            <tr>
              <th> Num_Vuelo </th>
              <th> Origen </th>
              <th> Destino </th>
              <th> Hora salida </th>
            </tr>';
        foreach($filas as $clave=> $valor)
        {
          echo '<tr>';
            echo '<td>'.$valor[5].'<td>';
            echo '<td>'.$valor['Origen'].'<td>';
          echo '</tr>';
        }
        echo '</table>';
        if (count($filas)>0)
        {
          $_SESSION['logueado']=true;
        }
      } catch (PDOException $e) {
        echo "Fallo en el listado" . $e->getMessage();
      }
    }
include 'pie.php';
