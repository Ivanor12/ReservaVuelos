<?php

print' 							
                                          </div>
                          <div class="cleared"></div>
                              </div>
                          </div>
                          <div class="cleared"></div>
                        </div>
                    </div>
                </div>
                <div class="cleared"></div>
                <div class="footer">
                    <div class="footer-body">
                      <div class="footer-text">
                            <p>Practica Acceso a BD con PDO<br>Curso:2020-2021</p>
                      </div>
                		<div class="cleared"></div>
                  </div>
                </div>
        		<div class="cleared"></div>
            </div>
        </div>
        <div class="cleared"></div>
        
    </div>
        </div>
    </div>
    
    
    
    
    
</body>
</html>
';
