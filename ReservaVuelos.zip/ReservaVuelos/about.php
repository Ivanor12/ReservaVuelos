<?php
session_start();
require_once 'clases/Conexion.php';
include 'head.php';
if (isset($_SESSION['logueado'])) {
    print '<h2>Ivan Ortega</h2>';
} else {
    header('Location: index.php');
}
include 'pie.php';

