<?php

include 'head.php';

$dni=$_REQUEST['dni'];
$num_vuelo=$_REQUEST['num_vuelo'];
$fecha=$_REQUEST['fecha'];
try {
    $obj_conexion = new Conexion();;
    $con = $obj_conexion->conectar();

    $sql ="delete from reservas where dni=? and fecha=? and Num_Vuelo=?";
    $listado = $con->prepare($sql);
    $listado->execute(array($dni,$fecha,$tipo));
    //Es un array asociativo con los registros de la consultas.
    $filas = $listado->fetchAll();

  } catch (PDOException $e) {
    echo "Fallo en el listado" . $e->getMessage();
  }

include 'pie.php';