<?php
define('DNS','mysql:dbname=reservas_vuelos;host=localhost');  
define('USERNAME','root');  
define('PASSWORD','toor');
?>

		