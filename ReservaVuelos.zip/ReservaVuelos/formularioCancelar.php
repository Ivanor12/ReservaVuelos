<?php
session_start();
require_once 'clases/Conexion.php';
if (isset($_SESSION['logueado'])) {
    include 'head.php';
    $obj_conexion = new Conexion();
    $con = $obj_conexion->conectar();
    if (isset($_REQUEST['cancelar'])) {
        try {
            $dni = $_REQUEST['dni'];
            $num_vuelo = $_REQUEST['num_vuelo'];
            $fecha = $_REQUEST['fecha'];
            $sql1 = "DELETE FROM reservas WHERE DNI=? AND Num_vuelo=? /*AND fecha=?*/";
            $cancelar = $con->prepare($sql1);
            $cancelar->execute(array($dni,$num_vuelo));
            echo '<script>alert("Registro Borrado Correctamente")</script>';

        } catch (PDOException $e) {
            echo "Fallo en la cancelacion de la reserva" . $e->getMessage();
        }
    } else {
        $sql2 = "SELECT * FROM vuelos";
		$lista = $con->prepare($sql2);
		$lista->execute();
        $filas = $lista->fetchAll();

echo '<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <table class="datos">
			<form action="borrar.php" method="POST">
				<tr><td>Introduzca el DNI :</td><td><input type="text" name="dni"></input></td></tr>
                                <tr>
                                    <td align="right">Numero de Vuelo :</td><td>
                                     <div align="left">
                                     <select name="num_vuelo">';                     
                                     foreach ($filas as $clave => $valor)
                                     {
                                         echo '<option value="' . $valor[0] . '">' . $valor[0] . '</option>';
                                     }	
                                  
                                     echo '</select>
                                 </div>
                             </td>
                             </tr>
                             <tr><td>Fecha:(aa/mm/dd)</td><td><input type="date" name="fecha"></input> </td></tr>
             <tr><td  colspan="2"><input type="submit" value="Cancelar Reserva" name="Cancelar"></td></tr>                       
         </form>
   </table>
 </body>
</html>';

include ('pie.php');
}

}

else
{
header('Location: index.php');
}