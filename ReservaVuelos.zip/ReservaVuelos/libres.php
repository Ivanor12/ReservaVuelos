<?php

include('head.php');
echo '<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <form action="" method="POST">
                <table class="datos">
			
				
                                <tr>
                                    <td align="right">Numero de Vuelo :</td><td>
                                 
                                        <select name="tipo">
                                         
                                        </select>
                                    
                                   </td>
                                  </tr>
                                  <tr><td>Fecha:(aa/mm/dd)</td><td><input type="date" name="fecha"></input> </td></tr>
				
                                
			
		</table>
                <center>
                    <br><input type="submit" value="Ver" name="Submit">
                </center>
          </form>
                
     </body>
</html>';





include ('pie.php');

