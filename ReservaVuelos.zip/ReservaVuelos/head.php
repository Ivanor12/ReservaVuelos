<?php

print'
    <!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8" />
    <title>Aplicacion Reserva de Vuelos</title>

    <link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/estilos.css" type="text/css" media="screen" />
    
    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
</head>
<body>
<div id="page-background-middle-texture">
        <div id="page-background-top-texture">
    <div id="main">
        <div class="sheet">
            <div class="sheet-body">
                <div class="header">
                    <div class="header-center">
                        
                    </div>
                    <div class="logo">
                      <h1 id="name-text" class="logo-name"><a href="">Aplicacion para Reservar Vuelos </a></h1>
                     <BR><h2 id="slogan-text" class="logo-text"> Practica Acceso a BD con PDO(2020/2021)</h2>
                    </div>
                </div>
                <div class="nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="menu">
                		<li>
                			<a href="inicio.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Inicio</span></a>
                		</li>
                                
                        <li>
                			<a href="listar.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Listado Vuelos </span></a>
                		</li>
                                <li>
                			<a href="formularioReservar.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Reservar Vuelo </span></a>
                		</li>
                                <li>
                			<a href="formularioCancelar.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Cancelar Reserva</span></a>
                		</li>
                		
                                <li>
                			<a href="libres.php"><span class="l"></span><span class="r"></span><span class="t">Nº ASIENTOS LIBRES</span></a>
                			
                		</li>
                               
                                
                		<li>
                			<a href="About.php"><span class="l"></span><span class="r"></span><span class="t">About</span></a>
                		</li>
                	</ul>
                </div>
                <div class="content-layout">
                    <div class="content-layout-row">
                        <div class="layout-cell content">
                          <div class="post">
                              <div class="post-body">
                          <div class="post-inner article">
                                          ';
