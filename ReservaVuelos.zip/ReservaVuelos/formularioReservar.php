<?php
session_start();
require_once 'clases/Conexion.php';
if (isset($_SESSION['logueado'])) {
      include 'head.php';
      try {
            $obj_conexion = new Conexion();
            $con = $obj_conexion->conectar();
            $sql ="insert into reservas values dni=? and fecha=? and Num_Vuelo=? and tipo=?";
            $listado = $con->prepare($sql);
            $listado->execute();
            //Es un array asociativo con los registros de la consultas.
            $filas = $listado->fetchAll();
      }
            catch (PDOException $e) {
                  echo "Fallo en el listado" . $e->getMessage();
                }

print'<!DOCTYPE html>
    <html>
	<head>
	</head>
	<body>
		<table class="datos">
			<form action="reservar.php" method="POST">
				<tr><td>DNI:</td><td><input type="text" name="dni"></input></td></tr>
				
				 <tr>
                                    <td align="right">Numero de Vuelo :</td><td>
                                     <div align="left">
                                        <select name="num_vuelo">
                                         
                                        </select>
                                    </div>
                                   </td>
                                  </tr>
                                <tr><td>Fecha: (aa/mm/dd)</td><td><input type="date" name="fecha"></input></td></tr>  
				<tr><td colspan="2">Elije la clase del pasaje:</td></tr>
				<tr><td>Business: <input type="radio" name="tipo" value="Business"></td><td>Turista: <input type="radio" name="tipo" value="Turista" checked></td></tr>
				<tr><td colspan="2"><input type="submit" value="Reservar" name="A�adir"></td></tr>
			</form>
		</table>
	</body>
   </html>';
            }
include ('pie.php');
     